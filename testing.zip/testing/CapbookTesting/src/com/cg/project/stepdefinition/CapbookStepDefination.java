package com.cg.project.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CapbookStepDefination {

	private WebDriver driver;

	private CapbookStepDefination pageBean;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver",
				"F:\\chromedriver.exe" );
		driver=new ChromeDriver();	
	}
	

@Given("^user is accessing the CapBook Registration Page$")
public void user_is_accessing_the_CapBook_Registration_Page() throws Throwable {
    driver = new ChromeDriver();
    driver.get("https://github.com/login");
    loginPage = PageFactory.initElements(driver, LoginPage.class);
    throw new PendingException();
}

@When("^user is trying to submit request after entering valid set of information$")
public void user_is_trying_to_submit_request_after_entering_valid_set_of_information() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^Your Registration has successfully done$")
public void your_Registration_has_successfully_done() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Given("^user is accessing Registration Page$")
public void user_is_accessing_Registration_Page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user is trying to submit data without entering 'firstName'$")
public void user_is_trying_to_submit_data_without_entering_firstName() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^'Please fill out this field\\.'$")
public void please_fill_out_this_field() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user is trying to submit data without entering 'lastName'$")
public void user_is_trying_to_submit_data_without_entering_lastName() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user is trying to submit data without entering 'date Of Birth'$")
public void user_is_trying_to_submit_data_without_entering_date_Of_Birth() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user is trying to submit data without entering 'gender'$")
public void user_is_trying_to_submit_data_without_entering_gender() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user is trying to submit data without 'emailId'$")
public void user_is_trying_to_submit_data_without_emailId() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^'Please fill out this field\\.Must maintain the syntax : someone@email\\.com\\.'$")
public void please_fill_out_this_field_Must_maintain_the_syntax_someone_email_com() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user is trying to submit data without entering 'Password'$")
public void user_is_trying_to_submit_data_without_entering_Password() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^'Please match the requested format\\.Must contain at least one number and one uppercase and lowercase letter, and at least (\\d+) or more characters'$")
public void please_match_the_requested_format_Must_contain_at_least_one_number_and_one_uppercase_and_lowercase_letter_and_at_least_or_more_characters(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user is trying to submit data without entering 'city'$")
public void user_is_trying_to_submit_data_without_entering_city() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^'Please fill out  this field'$")
public void please_fill_out_this_field() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user is trying to submit data without entering 'state'$")
public void user_is_trying_to_submit_data_without_entering_state() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user is trying to submit data without entering 'Country'$")
public void user_is_trying_to_submit_data_without_entering_Country() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user is trying to submit data without entering 'zipCode'$")
public void user_is_trying_to_submit_data_without_entering_zipCode() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user is trying to submit data without entering 'Security Ques'$")
public void user_is_trying_to_submit_data_without_entering_Security_Ques() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user is trying to submit data without entering 'Security Ques Answer'$")
public void user_is_trying_to_submit_data_without_entering_Security_Ques_Answer() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

